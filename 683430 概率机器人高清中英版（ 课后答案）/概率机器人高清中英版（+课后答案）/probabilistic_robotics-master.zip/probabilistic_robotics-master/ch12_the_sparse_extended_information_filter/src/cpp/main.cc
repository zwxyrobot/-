#include "seif.h"

int main(){

  seif();

  return 0;
}
